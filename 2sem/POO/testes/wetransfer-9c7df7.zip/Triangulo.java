import java.util.*;
import java.io.*;

public class Triangulo
{
    private Ponto x;
    private Ponto y;
    private Ponto z;

    public Triangulo(Ponto x, Ponto y, Ponto z)	{
    	this.x = x;
    	this.y = y;
    	this.z = z;
    }

    public double area() {
    	double b = this.getX().distancia(this.getY());
    	double a = this.getY().distancia(this.getZ());
    	return ((b*a)/2);
    }

    public Ponto getX() {
   	return this.x;
    }

    public Ponto getY() {
   	return this.y;
    }

    public Ponto getZ() {
   	return this.z;
    }
}