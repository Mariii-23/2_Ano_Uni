import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class Contribuinte extends Entidade {

    private String nome;
    private String nif;
    private int bonificado; //0 - Não; 1- Sim

    public Contribuinte() {
        super();
        this.nome = "";
        this.bonificado = 0;
    }

    public Contribuinte(String nome, String nif, int bonificado, Map<LocalDate, Fatura> faturas) {
        super();
        this.nome = nome;
        this.bonificado = bonificado;
    }

    public Contribuinte(Contribuinte c) {
        super();
        this.nome = c.getNome();
        this.bonificado = c.getBonificado();
    }
    
    public String getNif() {
        return super.getNif();
    }
    
    public String getNome() {
        return this.nome;
    }

    public int getBonificado() {
        return this.bonificado;
    }

    public Contribuinte clone() {
        return new Contribuinte(this);
    }
}