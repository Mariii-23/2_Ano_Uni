public interface Bonificado {
    public double reducaoImpost();
}
