import java.util.*;
import java.io.*;

public class Atividade {
    private String nome;
    
    public Atividade() {
        this.nome = "";
    }
    public Atividade(String nome){
        this.nome = nome;
    }
    
    public Atividade(Atividade a) {
        this.nome = a.getNome();
    }
    
    public String getNome() {
        return this.nome;
    }
    
    public Atividade clone() {
        return new Atividade(this);
    }
}
