import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class Fatura {
    
    private String numero;
    private LocalDate data;
    private double valor;
    private Atividade atividade;

    public Fatura() {
        this.numero = "";
        this.data = LocalDate.now();
        this.valor = 0.0;
        this.atividade = new Atividade();
    }

    public Fatura(String numero, LocalDate data, double valor, Atividade atividade) {
        this.numero = numero;
        this.data = data;
        this.valor = valor;
        this.atividade = atividade;
    }

    public Fatura(Fatura f) {
        this.numero = f.getNumero();
        this.data = f.getData();
        this.valor = f.getValor();
        this.atividade = f.getAtividade();
    }

    public String getNumero() {
        return this.numero;
    }

    public LocalDate getData() {
        return this.data;
    }

    public double getValor() {
        return this.valor;
    }

    public Atividade getAtividade() {
        return this.atividade.clone();
    }

    public Fatura clone() {
        return new Fatura(this);
    }
}