
public abstract class FamiliaNumerosa extends Contribuinte implements Bonificado  {

}
