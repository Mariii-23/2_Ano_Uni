import java.util.*;
import java.io.*;
import java.io.PrintWriter;

public class Negocio implements Serializable {
    private Map<String, Contribuinte> contribuintes;
    
    public void printFamiliasNumerosas(String nomeFich) throws FileNotFoundException {
        PrintWriter fich = new PrintWriter(nomeFich);
        for(Contribuinte c : contribuintes.values()) {
            fich.write("Nome: " + c.getNome() + "Nif: " + c.getNif() + "Bonificado: " + c.getBonificado());
        }
        fich.flush();
        fich.close();
    }
}
