import java.util.*;
import java.io.*;
import java.util.stream.Collectors;

public class CasaInteligente implements Serializable{
    private TreeMap<String, Lampada> lampadas;

    public CasaInteligente() {
        this.lampadas = new TreeMap<String,Lampada>();
    }

    public CasaInteligente(Collection<Lampada> novaslampadas) {
        Iterator<Lampada> it = novaslampadas.iterator();
        while(it.hasNext()) {
            Lampada l = it.next();
            this.lampadas.put(l.getIdent(), l.clone());
        }
    }

    public void addLampada(Lampada l) {
        this.lampadas.put(l.getIdent(), l.clone());
    }

    public int qtEmEco() {
        int res = 0;
        for(Lampada l : lampadas.values()) {
            if(l.getEstado() == 2) {
                res += 1;
            }
        }
        return res;
    }

    public void removeLampada(String id) throws LampadaNaoExisteException {
        if(lampadas.containsKey(id)) {
            lampadas.remove(id);
        } else {
            throw new LampadaNaoExisteException();
        }
    }

    public Set<String> topConsumo(int x) {
        TreeSet<Lampada> ord = new TreeSet<Lampada>(new ComparadorLampada());
        for(Lampada l : lampadas.values()) {
            ord.add(l.clone());
        }
        List<String> list = ord.stream().map(Lampada :: getIdent).limit(x).collect(Collectors.toList());
        Set<String> res = new LinkedHashSet<String>(list);
        return res;
    }

     public double consumoTotal() {
        double res = 0.0;
        for(Lampada l : lampadas.values()) {
            if(l instanceof LampadaLed) {
                LampadaLed ll = (LampadaLed) l;
                res += ll.getConsumoTotal() * ll.getPercentagem();
            } else if (l instanceof Lampada) {
                res += l.getConsumoTotal();
            }
        }
        return res;
    }
    
    class ComparadorLampada implements Comparator<Lampada> {

        public int compare(Lampada a, Lampada b) {
            return Double.valueOf(b.getConsumoTotal()).compareTo(a.getConsumoTotal());
        }
    }

    public void gravaFicheiro() throws LampLedWriteFail, FileNotFoundException, IOException {
        Scanner f = new Scanner(System.in);
        String file = f.next();
        FileOutputStream writeFile = new FileOutputStream(file); 
        if(writeFile == null) {                                  // Não necessário no teste
            throw new FileNotFoundException();                   // Não necessário no teste
        }
        ObjectOutputStream os = new ObjectOutputStream(writeFile); 
        if(os == null) {                                        // Não necessário no teste
            throw new IOException();                            // Não necessário no teste
        }
        for(Lampada l : lampadas.values()) {
            if(l instanceof LampadaLed) {
                LampadaLed ll = (LampadaLed) l;
                os.writeObject(ll);
            }
        }
        if(os == null) {
            throw new LampLedWriteFail();
        }
        os.flush();
        os.close();
    }
}