class LampadaNaoExisteException extends Exception {
    LampadaNaoExisteException() {
        super();
    }
    LampadaNaoExisteException(String s) {
        super(s);
    }
}
