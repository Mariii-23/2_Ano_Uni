import java.util.*;
import java.io.*;

public class LampadaLed extends Lampada implements Serializable {

    private double percentagem;

    public LampadaLed() {
        super();
        this.percentagem = 0.0;
    }

    public LampadaLed(String ident, double consumoTotal, double percentagem, int estado) {
        super(ident, consumoTotal, estado);
        this.percentagem = percentagem;
    }

    public LampadaLed (LampadaLed l) {
        super(l);
        this.percentagem = l.getPercentagem();   
    }
    
    public LampadaLed clone() {
        return new LampadaLed(this);
    }

    public double getPercentagem() {
        return this.percentagem;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        LampadaLed l = (LampadaLed) o;
        return super.equals(l) && this.percentagem == l.getPercentagem(); 
    }

    public String toString() {
        return super.toString() + "\n Percentagem: " + this.percentagem;
    }
}