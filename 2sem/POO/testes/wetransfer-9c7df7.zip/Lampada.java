import java.util.*;
import java.io.*;

public class Lampada
{
    private String ident;
    private double consumoTotal;
    private int estado;
    
    public Lampada() {
        this.ident = "";
        this.consumoTotal = 0.0;
    	this.estado = 0; 
    }

    public Lampada(String ident, double consumoTotal, int estado) {
        this.ident = ident;
        this.consumoTotal = consumoTotal;
    	this.estado = estado;
    }

    public Lampada(Lampada l) {
        this.ident = l.getIdent();
        this.consumoTotal = l.getConsumoTotal();
        this.estado = l.getEstado();
    }

    public String getIdent() {
        return this.ident;
    }

    public double getConsumoTotal() {
        return this.consumoTotal;
    }

    public int getEstado() {
    	return this.estado;
    }

    public Lampada clone() {
        return new Lampada(this);
    }

    public boolean equals(Object o) {
        if(this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Lampada l = (Lampada) o;
        return this.ident.equals(l.getIdent()) && this.consumoTotal == l.getConsumoTotal();
    }

    public String toString() {
        return "\n Id: " + this.ident + "\n ConsumoTotal: " + this.consumoTotal;
    }
}