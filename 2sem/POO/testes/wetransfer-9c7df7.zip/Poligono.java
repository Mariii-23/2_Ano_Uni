import java.util.*;
import java.io.*;

public class Poligono {

    private ArrayList<Ponto> pontos;

    public Poligono() {
        this.pontos = new ArrayList<Ponto>();
    }

    public Poligono(ArrayList<Ponto> pontos) {
        for(Ponto p : pontos) {
            this.pontos.add(p.clone());
        }
    }

    public Poligono(Poligono p) {
        this.pontos = p.getPontos();
    }

    public ArrayList<Ponto> getPontos() {
        ArrayList<Ponto> res = new ArrayList<Ponto>();
        for(Ponto p : this.pontos) {
            res.add(p.clone());
        }
        return res;
    }

    public void addPonto(Ponto p) {
        this.pontos.add(p.clone());
    }

    public boolean eFechada() {
        int size = this.pontos.size();
        if(size < 4) {
            return false;
        }
        if(this.pontos.get(0).equals(this.pontos.get(size - 1))) {
            return true;
        } else {
            return false;
        }
    }

    public double perimetro() {
        double perimetro = 0.0;
        int size = this.pontos.size();
        for(int i = 0; i < size - 2; i++) {
            perimetro += this.pontos.get(i).distancia(this.pontos.get(i+1));
        }
        return perimetro;
    }
    /*
    public double area() {
        return 0.0;
    } Pergunta 4a
    */
   
    //Utilizar esta classe para "simular" o 4b
    public double area() {
        double area = 0.0;
        int size = this.pontos.size();
        for(int i = 1; i < size - 2; i++) {
            Triangulo t = new Triangulo(this.pontos.get(0), this.pontos.get(i), this.pontos.get(i+1));
            area += t.area();
                        System.out.println(area);
        }
        return area;
    }
}