class LampLedWriteFail extends Exception {
    LampLedWriteFail() {
         super();
    }

    LampLedWriteFail(String s) {
         super(s);
    }

}
