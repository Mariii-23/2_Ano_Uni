import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.util.stream.Collectors;

public abstract class Entidade {
    private String nif;
    private Map<LocalDate, Fatura> faturas;

    public String getNif() {
        return this.nif;
    }

    public void addFatura(Fatura f) {
        faturas.put(f.getData(), f.clone());
    }

    public TreeSet<Fatura> ordena() {
        TreeSet<Fatura> res = new TreeSet<Fatura>(new ComparaDatas());
        for(Fatura f : faturas.values()) {
            res.add(f.clone());
        }
        return res;
    }
    
    public Map<Atividade, List<Fatura>> porAtividade() {
        return faturas.values().stream().map(Fatura::clone).collect(Collectors.groupingBy(Fatura::getAtividade));
    }
}